#include <stdio.h>

int main() {
    int defeitos;
    int totalDefeitos = 0;

    printf("Digite a quantidade de defeitos: ");
    scanf("%d", &defeitos);

    while (defeitos >= 0) {
        totalDefeitos = totalDefeitos + defeitos;

printf("Digite a quantidade de defeitos (ou negativo para sair): ");
        scanf("%d", &defeitos);
    }

    printf("total de defeitos registrado no turno: %d\n", totalDefeitos);

    return 0;
}